from django.apps import AppConfig


class SardorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sardor'
